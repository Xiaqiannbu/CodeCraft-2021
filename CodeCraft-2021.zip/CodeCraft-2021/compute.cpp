#include "compute.h"

unordered_map<string, int> ComputeNum::buyServerNum()
{
	return {};
}